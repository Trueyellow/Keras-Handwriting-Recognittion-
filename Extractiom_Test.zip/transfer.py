from __future__ import print_function
import os
from random import shuffle
import cv2
import numpy as np
import scipy.io as sio

np.random.seed(1337)  # for reproducibility

Names = ['train', 'validation']

data_image = []
data_label = []

DataList = []

for dirname in os.listdir(Names[0]):  # [1:] Excludes .DS_Store from Mac OS
    path = os.path.join(Names[0], dirname)

    if dirname.endswith(".jpg"):
        DataList.append(os.path.join(Names[0], dirname))

shuffle(DataList)
print(DataList)
num = 0
for filename in DataList:
    image = cv2.imread(filename)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # grayscale
    data_image.append(gray)

    num += 1
    print(num)

data = np.array(data_image)
print(data, 'DATAIMAGE')
sio.savemat('Testdata.mat', {'Testdata': data})

test = sio.loadmat('Testdata.mat')
print(test)